Welcome to TECHS-OS! 
A simple batch-based operating system.

All actions are immediately saved.

Proper Installation:
Change the File path variales in files:
TECHS-OS.bat (in the 'boot' folder) Amt: 1
shell.bat (in the 'bin' folder in the 'system' folder) Amt: 3

Create a sortcut to the TECHS-OS.bat file in the 'boot' folder,
and place it where ever you want.

And lastly place the TECHS-OS folder somewhere on the C or Main drive.
If you do not have a C drive, your main drive will be the drive windows is installed on.

Have fun!