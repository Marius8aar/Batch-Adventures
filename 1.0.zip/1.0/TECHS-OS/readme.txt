Welcome to TECHS-OS! 
A simple batch-based operating system.

All actions are immediately saved.

Proper Installation:
Change the File path variales in files:

